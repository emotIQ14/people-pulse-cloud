import { type User, type InsertUser, type HrModule, type InsertHrModule, type Conversation, type InsertConversation, type Analytics, type InsertAnalytics } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getHrModules(): Promise<HrModule[]>;
  getHrModule(id: string): Promise<HrModule | undefined>;
  getHrModuleByGptId(gptId: string): Promise<HrModule | undefined>;
  createHrModule(module: InsertHrModule): Promise<HrModule>;
  updateHrModuleUsage(id: string): Promise<void>;
  
  getConversations(userId: string): Promise<Conversation[]>;
  getConversation(id: string): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, messages: any[]): Promise<void>;
  
  getAnalytics(moduleId?: string): Promise<Analytics[]>;
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private hrModules: Map<string, HrModule>;
  private conversations: Map<string, Conversation>;
  private analytics: Map<string, Analytics>;

  constructor() {
    this.users = new Map();
    this.hrModules = new Map();
    this.conversations = new Map();
    this.analytics = new Map();
    
    // Initialize default HR modules
    this.initializeDefaultModules();
  }

  private initializeDefaultModules() {
    const defaultModules = [
      {
        name: "WritingStyle",
        description: "Análisis y mejora del estilo de escritura corporativa",
        gptId: "g-68d1688d71e48191889c015225baec14-writingstyle",
        isActive: true,
        usageCount: 12,
        lastUsed: new Date(),
      },
      {
        name: "SkillPathfinder",
        description: "Mapeo de competencias y rutas de desarrollo profesional",
        gptId: "g-68d166a718b081918a6006ad815c9c4a-skillpathfinder",
        isActive: true,
        usageCount: 340,
        lastUsed: new Date(),
      },
      {
        name: "PeopleAnalytics Pro",
        description: "Análisis de datos y métricas de talento humano",
        gptId: "g-68d1647c23ec8191b81e4b1f0669ef4e-peopleanalytics-pro",
        isActive: true,
        usageCount: 25,
        lastUsed: new Date(),
      },
      {
        name: "OrgDesign",
        description: "Diseño y optimización de estructura organizacional",
        gptId: "g-68d1633d08988191ae7105de015a4d33-orgdesign",
        isActive: true,
        usageCount: 8,
        lastUsed: new Date(),
      },
      {
        name: "HR Compliance",
        description: "Gestión de cumplimiento normativo y legal",
        gptId: "g-68d16168a04c81919432521ab15662d4-hr-compliance",
        isActive: true,
        usageCount: 0,
        lastUsed: new Date(),
      },
      {
        name: "DigitalTrans",
        description: "Estrategias de transformación digital en RRHH",
        gptId: "g-68d154580d4881919db958526b44be7f-digitaltrans",
        isActive: true,
        usageCount: 15,
        lastUsed: new Date(),
      },
      {
        name: "Culture Engage",
        description: "Análisis de cultura organizacional y engagement",
        gptId: "g-68d15307bfb08191bbd815b56c0d60ee-culture-engage",
        isActive: true,
        usageCount: 89,
        lastUsed: new Date(),
      },
      {
        name: "Comp Rewards",
        description: "Gestión de compensaciones y beneficios",
        gptId: "g-68d151a5368881919171253b58c5c47b-comp-rewards",
        isActive: true,
        usageCount: 95,
        lastUsed: new Date(),
      },
      {
        name: "CHRO Advisor",
        description: "Asesoría estratégica para directivos de RRHH",
        gptId: "g-68d14f394d68819184de6a67b8ca13e0-chro-advisor",
        isActive: true,
        usageCount: 18,
        lastUsed: new Date(),
      },
    ];

    defaultModules.forEach(module => {
      const id = randomUUID();
      const hrModule: HrModule = { 
        ...module, 
        id,
        lastUsed: module.lastUsed
      };
      this.hrModules.set(id, hrModule);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || "user",
      email: insertUser.email || null,
      fullName: insertUser.fullName || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getHrModules(): Promise<HrModule[]> {
    return Array.from(this.hrModules.values());
  }

  async getHrModule(id: string): Promise<HrModule | undefined> {
    return this.hrModules.get(id);
  }

  async getHrModuleByGptId(gptId: string): Promise<HrModule | undefined> {
    return Array.from(this.hrModules.values()).find(
      (module) => module.gptId === gptId,
    );
  }

  async createHrModule(insertModule: InsertHrModule): Promise<HrModule> {
    const id = randomUUID();
    const module: HrModule = { 
      ...insertModule, 
      id,
      description: insertModule.description || null,
      isActive: insertModule.isActive !== undefined ? insertModule.isActive : true,
      usageCount: 0,
      lastUsed: null
    };
    this.hrModules.set(id, module);
    return module;
  }

  async updateHrModuleUsage(id: string): Promise<void> {
    const module = this.hrModules.get(id);
    if (module) {
      module.usageCount = (module.usageCount || 0) + 1;
      module.lastUsed = new Date();
      this.hrModules.set(id, module);
    }
  }

  async getConversations(userId: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.userId === userId,
    );
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const conversation: Conversation = { 
      ...insertConversation, 
      id,
      title: insertConversation.title || null,
      userId: insertConversation.userId || null,
      moduleId: insertConversation.moduleId || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: string, messages: any[]): Promise<void> {
    const conversation = this.conversations.get(id);
    if (conversation) {
      conversation.messages = messages;
      conversation.updatedAt = new Date();
      this.conversations.set(id, conversation);
    }
  }

  async getAnalytics(moduleId?: string): Promise<Analytics[]> {
    const allAnalytics = Array.from(this.analytics.values());
    if (moduleId) {
      return allAnalytics.filter(analytics => analytics.moduleId === moduleId);
    }
    return allAnalytics;
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const id = randomUUID();
    const analytics: Analytics = { 
      ...insertAnalytics, 
      id,
      moduleId: insertAnalytics.moduleId || null,
      date: new Date()
    };
    this.analytics.set(id, analytics);
    return analytics;
  }
}

export const storage = new MemStorage();
