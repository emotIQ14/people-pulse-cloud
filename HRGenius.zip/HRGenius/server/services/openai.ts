import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AnalysisResult {
  analysis: string;
  recommendations: string[];
  confidence: number;
  metadata?: Record<string, any>;
}

export async function sendMessageToGPT(
  gptId: string, 
  messages: ChatMessage[], 
  systemPrompt?: string
): Promise<string> {
  try {
    const chatMessages: any[] = [];
    
    if (systemPrompt) {
      chatMessages.push({
        role: "system",
        content: systemPrompt
      });
    }
    
    chatMessages.push(...messages);

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: chatMessages,
    });

    return response.choices[0].message.content || "No response received";
  } catch (error: any) {
    throw new Error(`Failed to communicate with GPT: ${error.message}`);
  }
}

export async function analyzeWithGPT(
  gptId: string,
  content: string,
  analysisType: string,
  context?: string
): Promise<AnalysisResult> {
  try {
    const systemPrompt = `You are a specialized HR AI assistant for ${analysisType}. ${context || ''} 
    Analyze the provided content and respond with a JSON object containing:
    - analysis: detailed analysis of the content
    - recommendations: array of actionable recommendations
    - confidence: confidence score between 0 and 1
    - metadata: any additional relevant information`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: content
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      analysis: result.analysis || "No analysis provided",
      recommendations: result.recommendations || [],
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
      metadata: result.metadata || {}
    };
  } catch (error: any) {
    throw new Error(`Failed to analyze content: ${error.message}`);
  }
}

export function getModuleSystemPrompt(moduleName: string): string {
  const prompts: Record<string, string> = {
    "WritingStyle": "You are an expert in corporate writing style analysis. Help improve business communications, emails, policies, and documents. Focus on clarity, tone, professionalism, and brand consistency.",
    "SkillPathfinder": "You are a career development specialist. Create personalized skill development paths, identify competency gaps, and recommend training programs based on employee profiles and career goals.",
    "PeopleAnalytics Pro": "You are a people analytics expert. Analyze HR data, employee metrics, retention patterns, and provide data-driven insights for workforce optimization and talent management.",
    "OrgDesign": "You are an organizational design consultant. Analyze organizational structures, recommend improvements for efficiency, collaboration, and scalability based on business needs.",
    "HR Compliance": "You are an HR compliance specialist. Ensure adherence to labor laws, regulations, policies, and provide guidance on legal HR matters and risk mitigation.",
    "DigitalTrans": "You are a digital transformation expert for HR. Recommend digital solutions, automation strategies, and technology implementations to modernize HR processes.",
    "Culture Engage": "You are a culture and engagement specialist. Analyze organizational culture, employee engagement levels, and recommend strategies to improve workplace satisfaction and retention.",
    "Comp Rewards": "You are a compensation and benefits expert. Analyze salary structures, benefit packages, pay equity, and recommend competitive compensation strategies.",
    "CHRO Advisor": "You are a strategic HR advisor for C-level executives. Provide high-level HR strategy, workforce planning, and executive-level recommendations for organizational success."
  };
  
  return prompts[moduleName] || "You are an HR specialist assistant.";
}
