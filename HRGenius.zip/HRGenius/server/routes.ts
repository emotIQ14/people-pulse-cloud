import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { sendMessageToGPT, analyzeWithGPT, getModuleSystemPrompt } from "./services/openai";
import { insertConversationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all HR modules
  app.get("/api/modules", async (req, res) => {
    try {
      const modules = await storage.getHrModules();
      res.json(modules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  // Get specific module
  app.get("/api/modules/:id", async (req, res) => {
    try {
      const module = await storage.getHrModule(req.params.id);
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      res.json(module);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch module" });
    }
  });

  // Chat with a specific module
  app.post("/api/modules/:id/chat", async (req, res) => {
    try {
      const module = await storage.getHrModule(req.params.id);
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }

      const { message, conversationId } = req.body;
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const systemPrompt = getModuleSystemPrompt(module.name);
      const messages = [{ role: "user" as const, content: message }];

      // If there's an existing conversation, get the history
      if (conversationId) {
        const conversation = await storage.getConversation(conversationId);
        if (conversation && conversation.messages) {
          messages.unshift(...(conversation.messages as any[]));
        }
      }

      const response = await sendMessageToGPT(module.gptId, messages, systemPrompt);

      // Update module usage
      await storage.updateHrModuleUsage(module.id);

      // Save or update conversation
      const updatedMessages = [...messages, { role: "assistant", content: response }];
      
      if (conversationId) {
        await storage.updateConversation(conversationId, updatedMessages);
      } else {
        // Create new conversation (assuming userId = "default" for now)
        await storage.createConversation({
          userId: "default",
          moduleId: module.id,
          title: message.substring(0, 50) + "...",
          messages: updatedMessages
        });
      }

      res.json({ response, conversationId });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ message: error.message || "Failed to process chat message" });
    }
  });

  // Analyze content with a specific module
  app.post("/api/modules/:id/analyze", async (req, res) => {
    try {
      const module = await storage.getHrModule(req.params.id);
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }

      const { content, context } = req.body;
      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }

      const result = await analyzeWithGPT(
        module.gptId, 
        content, 
        module.name, 
        context
      );

      // Update module usage
      await storage.updateHrModuleUsage(module.id);

      res.json(result);
    } catch (error: any) {
      console.error("Analysis error:", error);
      res.status(500).json({ message: error.message || "Failed to analyze content" });
    }
  });

  // Get conversations for a user
  app.get("/api/conversations", async (req, res) => {
    try {
      // Using default user for now
      const conversations = await storage.getConversations("default");
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  // Get analytics
  app.get("/api/analytics", async (req, res) => {
    try {
      const { moduleId } = req.query;
      const analytics = await storage.getAnalytics(moduleId as string);
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const modules = await storage.getHrModules();
      const totalUsage = modules.reduce((sum, module) => sum + (module.usageCount || 0), 0);
      const activeModules = modules.filter(module => module.isActive).length;
      
      // Mock stats for demonstration
      const stats = {
        activeEmployees: 1247,
        retentionRate: 94.2,
        newHires: 23,
        aiQueries: totalUsage,
        activeModules: activeModules
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
