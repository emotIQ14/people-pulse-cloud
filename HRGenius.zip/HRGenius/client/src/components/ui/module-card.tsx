import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface ModuleCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  iconColor: string;
  usageCount?: number;
  performance?: string;
  isActive?: boolean;
  onClick?: () => void;
}

export default function ModuleCard({
  title,
  description,
  icon: Icon,
  iconColor,
  usageCount,
  performance,
  isActive = true,
  onClick
}: ModuleCardProps) {
  return (
    <Card 
      className="shadow-sm cursor-pointer transition-all duration-200 hover:shadow-md hover:-translate-y-1" 
      onClick={onClick}
      data-testid={`module-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center transition-transform duration-300 hover:scale-110`} style={{ backgroundColor: `${iconColor}20` }}>
            <Icon className={`w-6 h-6`} style={{ color: iconColor }} />
          </div>
          <Badge 
            variant={isActive ? "default" : "secondary"}
            className={isActive ? "bg-accent text-accent-foreground" : ""}
            data-testid={`module-status-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            {isActive ? "Activo" : "Inactivo"}
          </Badge>
        </div>
        
        <h4 className="text-base font-semibold text-foreground mb-2" data-testid={`module-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {title}
        </h4>
        
        <p className="text-sm text-muted-foreground mb-4" data-testid={`module-description-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          {description}
        </p>
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground" data-testid={`module-usage-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {usageCount !== undefined ? `${usageCount} usos` : "Sin datos"}
          </span>
          {performance && (
            <span className="text-accent font-medium" data-testid={`module-performance-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {performance}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
