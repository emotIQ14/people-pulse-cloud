import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  title: string;
  description?: string;
}

export default function Header({ title, description }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border shadow-sm">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className="lg:hidden"
            data-testid="mobile-menu-button"
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div>
            <h2 className="text-xl font-semibold text-foreground" data-testid="page-title">
              {title}
            </h2>
            {description && (
              <p className="text-sm text-muted-foreground" data-testid="page-description">
                {description}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-sm font-medium text-foreground" data-testid="user-name">
                Usuario Demo
              </p>
              <p className="text-xs text-muted-foreground" data-testid="user-role">
                HR Director
              </p>
            </div>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-primary-foreground" data-testid="user-avatar">
                UD
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
