import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import WritingStylePage from "./pages/modules/writingstyle";
import SkillPathfinderPage from "./pages/modules/skillpathfinder";
import PeopleAnalyticsPage from "./pages/modules/peopleanalytics";
import OrgDesignPage from "./pages/modules/orgdesign";
import CompliancePage from "./pages/modules/compliance";
import DigitalTransPage from "./pages/modules/digitaltrans";
import CulturePage from "./pages/modules/culture";
import RewardsPage from "./pages/modules/rewards";
import ChroPage from "./pages/modules/chro";
import Sidebar from "@/components/layout/sidebar";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/modules/writingstyle" component={WritingStylePage} />
      <Route path="/modules/skillpathfinder" component={SkillPathfinderPage} />
      <Route path="/modules/peopleanalytics" component={PeopleAnalyticsPage} />
      <Route path="/modules/orgdesign" component={OrgDesignPage} />
      <Route path="/modules/compliance" component={CompliancePage} />
      <Route path="/modules/digitaltrans" component={DigitalTransPage} />
      <Route path="/modules/culture" component={CulturePage} />
      <Route path="/modules/rewards" component={RewardsPage} />
      <Route path="/modules/chro" component={ChroPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="flex h-screen">
          <Sidebar />
          <div className="lg:ml-64 flex flex-col flex-1">
            <Router />
          </div>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
