import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, Users, BarChart3, Shield, Gift, Target, AlertTriangle } from "lucide-react";

export default function RewardsPage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "Comp Rewards")
  });

  return (
    <>
      <Header 
        title="Comp & Rewards" 
        description="Gestión inteligente de compensaciones y beneficios con análisis de equidad salarial"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="w-5 h-5 text-yellow-600" />
                <span>Compensaciones y Beneficios</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Gestiona estrategias de compensación competitivas, analiza equidad salarial y optimiza 
                paquetes de beneficios. Utiliza IA para benchmarking de mercado, análisis de brechas 
                salariales y recomendaciones de ajustes de compensación.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview" data-testid="tab-overview">Resumen Ejecutivo</TabsTrigger>
              <TabsTrigger value="equity" data-testid="tab-equity">Equidad Salarial</TabsTrigger>
              <TabsTrigger value="benefits" data-testid="tab-benefits">Beneficios</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Métricas clave */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="compensation-metrics-title">Métricas de Compensación</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg">
                      <DollarSign className="w-12 h-12 text-yellow-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-yellow-600" data-testid="equity-score">95%</div>
                      <div className="text-sm text-yellow-700">Índice de Equidad</div>
                      <Badge className="mt-2 bg-green-100 text-green-800" data-testid="equity-status">
                        Excelente
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <BarChart3 className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-blue-600" data-testid="market-position">P75</div>
                        <div className="text-sm text-blue-700">Posición Mercado</div>
                      </div>

                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-green-600" data-testid="satisfaction-comp">4.3/5</div>
                        <div className="text-sm text-green-700">Satisfacción Comp.</div>
                      </div>

                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-purple-600" data-testid="retention-rate">94.2%</div>
                        <div className="text-sm text-purple-700">Retención</div>
                      </div>

                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <Target className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-orange-600" data-testid="budget-utilization">87%</div>
                        <div className="text-sm text-orange-700">Utilización Budget</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Análisis de bandas salariales */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="salary-bands-title">Análisis de Bandas Salariales</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="band-executive">Ejecutivo</span>
                          <span className="text-sm text-green-600 font-medium">Competitivo</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-green-500 rounded-full" style={{ width: '85%' }}></div>
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>$120K - $200K</span>
                          <span>P75 mercado</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="band-senior">Senior</span>
                          <span className="text-sm text-green-600 font-medium">Competitivo</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-green-500 rounded-full" style={{ width: '82%' }}></div>
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>$80K - $130K</span>
                          <span>P70 mercado</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="band-mid">Mid-Level</span>
                          <span className="text-sm text-blue-600 font-medium">Alineado</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-blue-500 rounded-full" style={{ width: '75%' }}></div>
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>$55K - $85K</span>
                          <span>P60 mercado</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="band-junior">Junior</span>
                          <span className="text-sm text-yellow-600 font-medium">Revisar</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-yellow-500 rounded-full" style={{ width: '68%' }}></div>
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>$35K - $60K</span>
                          <span>P45 mercado</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="recommendations-title">
                        Recomendaciones
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="w-4 h-4 text-green-600" />
                          <span className="text-muted-foreground" data-testid="rec-executive">
                            Ejecutivo: Mantener posicionamiento actual
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-600" />
                          <span className="text-muted-foreground" data-testid="rec-junior">
                            Junior: Ajuste del 8% para mejorar competitividad
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Insights y alertas */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="compensation-insights-title">Insights de Compensación</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Shield className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-green-900" data-testid="insight-retention">Alta Retención</h4>
                          <p className="text-xs text-green-700 mt-1">
                            La estrategia de compensación actual mantiene una retención del 94.2%, 
                            superando el benchmark del sector (89%).
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <BarChart3 className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900" data-testid="insight-benchmarking">Benchmarking Competitivo</h4>
                          <p className="text-xs text-blue-700 mt-1">
                            Posicionamiento en P75 del mercado asegura atracción de talento top. 
                            Especialmente fuerte en roles técnicos.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-yellow-900" data-testid="insight-adjustment">Ajuste Requerido</h4>
                          <p className="text-xs text-yellow-700 mt-1">
                            Los roles junior requieren ajuste del 8% para mantener competitividad 
                            y reducir rotación en esos niveles.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="equity" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Análisis de equidad */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="pay-equity-analysis-title">Análisis de Equidad Salarial</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                      <Shield className="w-12 h-12 text-green-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-green-600" data-testid="pay-equity-score">98.5%</div>
                      <div className="text-sm text-green-700">Equidad de Género</div>
                      <div className="text-xs text-green-600 mt-1">Sin brechas significativas</div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="equity-executive-level">Nivel Ejecutivo</span>
                          <span className="text-sm text-green-600 font-medium">100%</span>
                        </div>
                        <Progress value={100} className="h-2" />
                        <div className="text-xs text-muted-foreground mt-1">
                          Brecha: $0 (0.0%)
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="equity-senior-level">Nivel Senior</span>
                          <span className="text-sm text-green-600 font-medium">99.2%</span>
                        </div>
                        <Progress value={99.2} className="h-2" />
                        <div className="text-xs text-muted-foreground mt-1">
                          Brecha: $1,200 (0.8%)
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="equity-mid-level">Nivel Medio</span>
                          <span className="text-sm text-green-600 font-medium">97.8%</span>
                        </div>
                        <Progress value={97.8} className="h-2" />
                        <div className="text-xs text-muted-foreground mt-1">
                          Brecha: $1,800 (2.2%)
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="equity-junior-level">Nivel Junior</span>
                          <span className="text-sm text-yellow-600 font-medium">96.5%</span>
                        </div>
                        <Progress value={96.5} className="h-2" />
                        <div className="text-xs text-muted-foreground mt-1">
                          Brecha: $2,100 (3.5%)
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Diversidad en compensación */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="diversity-compensation-title">Diversidad en Compensación</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-blue-600" data-testid="gender-diversity">52/48</div>
                        <div className="text-sm text-blue-700">Ratio M/F</div>
                      </div>

                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <Target className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-purple-600" data-testid="ethnic-diversity">35%</div>
                        <div className="text-sm text-purple-700">Diversidad Étnica</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-green-900" data-testid="leadership-diversity">Liderazgo</span>
                          <span className="text-sm text-green-600">45% mujeres</span>
                        </div>
                        <div className="text-xs text-green-700 mt-1">
                          Meta: 40% | Estado: Superado
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-blue-900" data-testid="tech-diversity">Tecnología</span>
                          <span className="text-sm text-blue-600">38% mujeres</span>
                        </div>
                        <div className="text-xs text-blue-700 mt-1">
                          Meta: 35% | Estado: Superado
                        </div>
                      </div>

                      <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-purple-900" data-testid="stem-diversity">STEM Roles</span>
                          <span className="text-sm text-purple-600">42% diversidad</span>
                        </div>
                        <div className="text-xs text-purple-700 mt-1">
                          Meta: 40% | Estado: Alcanzado
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="equity-actions-title">
                        Acciones de Equidad
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center space-x-2">
                          <Target className="w-4 h-4 text-green-600" />
                          <span className="text-muted-foreground" data-testid="action-maintain">
                            Mantener programas de desarrollo para mujeres en tech
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-600" />
                          <span className="text-muted-foreground" data-testid="action-adjust">
                            Ajustar compensación en niveles junior para cerrar brecha
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="benefits" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Portafolio de beneficios */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="benefits-portfolio-title">Portafolio de Beneficios</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Shield className="w-5 h-5 text-green-600" />
                          <div>
                            <div className="font-medium" data-testid="benefit-health">Seguro de Salud</div>
                            <div className="text-sm text-muted-foreground">Cobertura 100% empleado + familia</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-green-600">100%</div>
                          <div className="text-xs text-green-500">Adoptado</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Gift className="w-5 h-5 text-blue-600" />
                          <div>
                            <div className="font-medium" data-testid="benefit-flexible">Beneficios Flexibles</div>
                            <div className="text-sm text-muted-foreground">$2,000 anuales para elección</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-blue-600">87%</div>
                          <div className="text-xs text-blue-500">Utilización</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="w-5 h-5 text-purple-600" />
                          <div>
                            <div className="font-medium" data-testid="benefit-learning">Desarrollo Profesional</div>
                            <div className="text-sm text-muted-foreground">$3,000 anuales + tiempo pagado</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-purple-600">92%</div>
                          <div className="text-xs text-purple-500">Participación</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Target className="w-5 h-5 text-orange-600" />
                          <div>
                            <div className="font-medium" data-testid="benefit-wellness">Programa Bienestar</div>
                            <div className="text-sm text-muted-foreground">Gym, mental health, nutrition</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-orange-600">78%</div>
                          <div className="text-xs text-orange-500">Engagement</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-teal-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <DollarSign className="w-5 h-5 text-teal-600" />
                          <div>
                            <div className="font-medium" data-testid="benefit-retirement">Plan de Pensiones</div>
                            <div className="text-sm text-muted-foreground">6% matching + gestión profesional</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-teal-600">95%</div>
                          <div className="text-xs text-teal-500">Inscripción</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* ROI y satisfacción */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="benefits-roi-title">ROI y Satisfacción</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                      <Gift className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-blue-600" data-testid="benefits-satisfaction">4.7/5</div>
                      <div className="text-sm text-blue-700">Satisfacción Beneficios</div>
                      <div className="text-xs text-blue-600 mt-1">Top quartile industry</div>
                    </div>

                    <div className="space-y-3">
                      <div className="p-3 bg-green-50 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-green-900" data-testid="roi-retention">Impacto en Retención</span>
                          <span className="text-sm text-green-600">+12%</span>
                        </div>
                        <div className="text-xs text-green-700">
                          Los beneficios contribuyen significativamente a la retención de talento.
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-blue-900" data-testid="roi-productivity">Productividad</span>
                          <span className="text-sm text-blue-600">+8%</span>
                        </div>
                        <div className="text-xs text-blue-700">
                          Programas de bienestar mejoran productividad y reducen ausentismo.
                        </div>
                      </div>

                      <div className="p-3 bg-purple-50 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-purple-900" data-testid="roi-attraction">Atracción Talento</span>
                          <span className="text-sm text-purple-600">+25%</span>
                        </div>
                        <div className="text-xs text-purple-700">
                          Paquete competitivo mejora la propuesta de valor para candidatos.
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="benefits-optimization-title">
                        Optimizaciones Sugeridas
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="w-4 h-4 text-green-600" />
                          <span className="text-muted-foreground" data-testid="opt-wellness">
                            Expandir programa de wellness mental (+15% engagement proyectado)
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Gift className="w-4 h-4 text-blue-600" />
                          <span className="text-muted-foreground" data-testid="opt-flexible">
                            Incrementar presupuesto beneficios flexibles a $2,500
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Target className="w-4 h-4 text-purple-600" />
                          <span className="text-muted-foreground" data-testid="opt-childcare">
                            Considerar beneficio de cuidado infantil para familias jóvenes
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
