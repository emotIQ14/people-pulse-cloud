import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle, AlertTriangle, FileText, Calendar, Users } from "lucide-react";

export default function CompliancePage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "HR Compliance")
  });

  return (
    <>
      <Header 
        title="HR Compliance" 
        description="Gestión automatizada de cumplimiento normativo y legal en recursos humanos"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5 text-red-600" />
                <span>Sistema de Cumplimiento Normativo</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Automatiza el seguimiento y gestión del cumplimiento de normativas laborales, 
                políticas internas y regulaciones legales. Identifica riesgos de incumplimiento 
                y proporciona alertas proactivas para mantener la organización protegida.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="status" className="space-y-4">
            <TabsList>
              <TabsTrigger value="status" data-testid="tab-status">Estado de Cumplimiento</TabsTrigger>
              <TabsTrigger value="audits" data-testid="tab-audits">Auditorías y Controles</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="status" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Estado general */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="compliance-status-title">Estado General de Cumplimiento</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center p-6 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-green-600" data-testid="compliance-score">100%</div>
                      <div className="text-sm text-green-700">Cumplimiento Total</div>
                      <Badge className="mt-2 bg-green-100 text-green-800" data-testid="compliance-badge">
                        0 Incidencias Activas
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="labor-laws">Legislación Laboral</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Cumple</Badge>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="data-protection">Protección de Datos</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Cumple</Badge>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="safety-standards">Normas de Seguridad</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Cumple</Badge>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="internal-policies">Políticas Internas</span>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">Cumple</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Próximas revisiones */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="upcoming-reviews-title">Próximas Revisiones</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center space-x-3">
                          <Calendar className="w-5 h-5 text-blue-600" />
                          <div>
                            <div className="font-medium text-blue-900" data-testid="review-equality">Revisión de Igualdad</div>
                            <div className="text-sm text-blue-700">Análisis anual obligatorio</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-blue-900">15 Mar 2025</div>
                          <div className="text-xs text-blue-700">En 45 días</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-purple-600" />
                          <div>
                            <div className="font-medium text-purple-900" data-testid="review-contracts">Auditoría de Contratos</div>
                            <div className="text-sm text-purple-700">Revisión trimestral</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-purple-900">30 Mar 2025</div>
                          <div className="text-xs text-purple-700">En 60 días</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-orange-600" />
                          <div>
                            <div className="font-medium text-orange-900" data-testid="review-training">Certificación de Capacitación</div>
                            <div className="text-sm text-orange-700">Renovación anual</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-orange-900">15 Abr 2025</div>
                          <div className="text-xs text-orange-700">En 75 días</div>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="automated-monitoring-title">
                        Monitoreo Automatizado
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Políticas actualizadas:</span>
                          <span className="font-medium text-green-600" data-testid="policies-updated">100%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Empleados capacitados:</span>
                          <span className="font-medium text-green-600" data-testid="employees-trained">98.5%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Documentación completa:</span>
                          <span className="font-medium text-green-600" data-testid="documentation-complete">100%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="audits" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Controles automáticos */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="automatic-controls-title">Controles Automáticos</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium" data-testid="control-contracts">Contratos</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium" data-testid="control-hours">Horas trabajadas</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium" data-testid="control-benefits">Beneficios</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-medium" data-testid="control-documentation">Documentación</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Auditorías recientes */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="recent-audits-title">Auditorías Recientes</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-blue-900" data-testid="audit-payroll">Nómina Q4 2024</span>
                        <Badge className="bg-blue-100 text-blue-800">Completada</Badge>
                      </div>
                      <div className="text-xs text-blue-700">Resultado: Sin observaciones</div>
                      <div className="text-xs text-blue-600">15 Ene 2025</div>
                    </div>

                    <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-green-900" data-testid="audit-safety">Seguridad Laboral</span>
                        <Badge className="bg-green-100 text-green-800">Aprobada</Badge>
                      </div>
                      <div className="text-xs text-green-700">Resultado: 100% conforme</div>
                      <div className="text-xs text-green-600">08 Ene 2025</div>
                    </div>

                    <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-purple-900" data-testid="audit-privacy">Privacidad GDPR</span>
                        <Badge className="bg-purple-100 text-purple-800">Certificada</Badge>
                      </div>
                      <div className="text-xs text-purple-700">Resultado: Excelente</div>
                      <div className="text-xs text-purple-600">20 Dic 2024</div>
                    </div>
                  </CardContent>
                </Card>

                {/* Alertas y recomendaciones */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="alerts-recommendations-title">Alertas y Recomendaciones</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-start space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-medium text-green-900" data-testid="alert-all-clear">Sistema Operativo</div>
                          <div className="text-xs text-green-700 mt-1">
                            Todos los controles están funcionando correctamente. 
                            No hay alertas activas en el sistema.
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-start space-x-2">
                        <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <div className="font-medium text-blue-900" data-testid="recommendation-updates">Actualización Preventiva</div>
                          <div className="text-xs text-blue-700 mt-1">
                            Se recomienda revisar las políticas de teletrabajo 
                            para alinearse con nuevas regulaciones.
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-start space-x-2">
                        <Calendar className="w-5 h-5 text-orange-600 mt-0.5" />
                        <div>
                          <div className="font-medium text-orange-900" data-testid="recommendation-training">Capacitación Programada</div>
                          <div className="text-xs text-orange-700 mt-1">
                            Programar sesiones de actualización en nuevas 
                            regulaciones de privacidad para el equipo.
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
