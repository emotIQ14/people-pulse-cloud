import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Heart, TrendingUp, Users, MessageCircle, Award, Target, Smile, Coffee } from "lucide-react";

export default function CulturePage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "Culture Engage")
  });

  return (
    <>
      <Header 
        title="Culture Engage" 
        description="Análisis de cultura organizacional y medición de engagement de empleados en tiempo real"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Heart className="w-5 h-5 text-pink-600" />
                <span>Cultura Organizacional y Engagement</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Monitorea y analiza la cultura organizacional, mide el engagement de los empleados 
                y proporciona insights para mejorar el clima laboral. Utiliza IA para identificar 
                patrones de satisfacción y áreas de mejora en la experiencia del empleado.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="engagement" className="space-y-4">
            <TabsList>
              <TabsTrigger value="engagement" data-testid="tab-engagement">Engagement Score</TabsTrigger>
              <TabsTrigger value="culture" data-testid="tab-culture">Cultura Organizacional</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="engagement" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Métricas principales */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="engagement-overview-title">Resumen de Engagement</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gradient-to-r from-pink-50 to-rose-50 rounded-lg">
                      <Heart className="w-12 h-12 text-pink-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-pink-600" data-testid="overall-engagement">89%</div>
                      <div className="text-sm text-pink-700">Engagement General</div>
                      <Badge className="mt-2 bg-pink-100 text-pink-800" data-testid="engagement-trend">
                        +5% este mes
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <Smile className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-green-600" data-testid="satisfaction-score">4.6/5</div>
                        <div className="text-sm text-green-700">Satisfacción</div>
                      </div>

                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-blue-600" data-testid="motivation-score">87%</div>
                        <div className="text-sm text-blue-700">Motivación</div>
                      </div>

                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <Award className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-purple-600" data-testid="recognition-score">92%</div>
                        <div className="text-sm text-purple-700">Reconocimiento</div>
                      </div>

                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <TrendingUp className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-orange-600" data-testid="growth-score">85%</div>
                        <div className="text-sm text-orange-700">Crecimiento</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Engagement por departamento */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="engagement-by-department-title">Engagement por Departamento</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-engineering-engagement">Ingeniería</span>
                          <span className="text-sm text-green-600 font-medium">94%</span>
                        </div>
                        <Progress value={94} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-design-engagement">Diseño</span>
                          <span className="text-sm text-green-600 font-medium">91%</span>
                        </div>
                        <Progress value={91} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-marketing-engagement">Marketing</span>
                          <span className="text-sm text-green-600 font-medium">88%</span>
                        </div>
                        <Progress value={88} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-sales-engagement">Ventas</span>
                          <span className="text-sm text-green-600 font-medium">87%</span>
                        </div>
                        <Progress value={87} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-operations-engagement">Operaciones</span>
                          <span className="text-sm text-yellow-600 font-medium">82%</span>
                        </div>
                        <Progress value={82} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="dept-finance-engagement">Finanzas</span>
                          <span className="text-sm text-yellow-600 font-medium">79%</span>
                        </div>
                        <Progress value={79} className="h-2" />
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="improvement-actions-title">
                        Acciones de Mejora
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center space-x-2">
                          <Target className="w-4 h-4 text-orange-600" />
                          <span className="text-muted-foreground" data-testid="action-operations">
                            Operaciones: Implementar programa de desarrollo profesional
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MessageCircle className="w-4 h-4 text-blue-600" />
                          <span className="text-muted-foreground" data-testid="action-finance">
                            Finanzas: Mejorar comunicación entre niveles
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Feedback reciente */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="recent-feedback-title">Feedback Reciente</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Smile className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-green-900" data-testid="feedback-positive-1">Ambiente Colaborativo</h4>
                          <p className="text-xs text-green-700 mt-1">
                            "Excelente ambiente de trabajo y apoyo entre compañeros. 
                            Me siento valorado y escuchado."
                          </p>
                          <div className="text-xs text-green-600 mt-2">Ingeniería • hace 2 días</div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Award className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900" data-testid="feedback-positive-2">Crecimiento Profesional</h4>
                          <p className="text-xs text-blue-700 mt-1">
                            "Las oportunidades de aprendizaje y desarrollo son excepcionales. 
                            Constantemente adquiero nuevas habilidades."
                          </p>
                          <div className="text-xs text-blue-600 mt-2">Diseño • hace 1 día</div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <MessageCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-yellow-900" data-testid="feedback-improvement">Comunicación</h4>
                          <p className="text-xs text-yellow-700 mt-1">
                            "Sería útil tener más feedback frecuente de los managers 
                            y claridad en objetivos trimestrales."
                          </p>
                          <div className="text-xs text-yellow-600 mt-2">Operaciones • hace 3 días</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="culture" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Valores organizacionales */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="organizational-values-title">Valores Organizacionales</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Target className="w-5 h-5 text-blue-600" />
                          <span className="font-medium" data-testid="value-innovation">Innovación</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-blue-600">95%</div>
                          <div className="text-xs text-blue-500">Adopción</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="value-collaboration">Colaboración</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-green-600">93%</div>
                          <div className="text-xs text-green-500">Adopción</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Award className="w-5 h-5 text-purple-600" />
                          <span className="font-medium" data-testid="value-excellence">Excelencia</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-purple-600">90%</div>
                          <div className="text-xs text-purple-500">Adopción</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Heart className="w-5 h-5 text-orange-600" />
                          <span className="font-medium" data-testid="value-care">Cuidado</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-orange-600">88%</div>
                          <div className="text-xs text-orange-500">Adopción</div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-teal-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="w-5 h-5 text-teal-600" />
                          <span className="font-medium" data-testid="value-growth">Crecimiento</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-teal-600">85%</div>
                          <div className="text-xs text-teal-500">Adopción</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Iniciativas culturales */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="cultural-initiatives-title">Iniciativas Culturales</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                      <div className="flex items-center space-x-3 mb-3">
                        <Coffee className="w-5 h-5 text-blue-600" />
                        <h4 className="font-medium text-blue-900" data-testid="initiative-coffee-chats">Coffee Chats</h4>
                      </div>
                      <p className="text-sm text-blue-700 mb-2">
                        Encuentros informales semanales para fomentar conexiones entre departamentos.
                      </p>
                      <div className="flex justify-between text-xs">
                        <span className="text-blue-600">Participación: 78%</span>
                        <span className="text-blue-600">Satisfacción: 4.5/5</span>
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-green-50 to-green-100 rounded-lg border border-green-200">
                      <div className="flex items-center space-x-3 mb-3">
                        <Award className="w-5 h-5 text-green-600" />
                        <h4 className="font-medium text-green-900" data-testid="initiative-recognition">Programa de Reconocimiento</h4>
                      </div>
                      <p className="text-sm text-green-700 mb-2">
                        Sistema peer-to-peer para reconocer logros y comportamientos alineados con valores.
                      </p>
                      <div className="flex justify-between text-xs">
                        <span className="text-green-600">Nominaciones: 245/mes</span>
                        <span className="text-green-600">Impacto: Alto</span>
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg border border-purple-200">
                      <div className="flex items-center space-x-3 mb-3">
                        <Target className="w-5 h-5 text-purple-600" />
                        <h4 className="font-medium text-purple-900" data-testid="initiative-innovation">Innovation Days</h4>
                      </div>
                      <p className="text-sm text-purple-700 mb-2">
                        Días dedicados a proyectos creativos y exploración de nuevas ideas.
                      </p>
                      <div className="flex justify-between text-xs">
                        <span className="text-purple-600">Proyectos: 42</span>
                        <span className="text-purple-600">Implementados: 8</span>
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg border border-orange-200">
                      <div className="flex items-center space-x-3 mb-3">
                        <Users className="w-5 h-5 text-orange-600" />
                        <h4 className="font-medium text-orange-900" data-testid="initiative-wellness">Bienestar Integral</h4>
                      </div>
                      <p className="text-sm text-orange-700 mb-2">
                        Programas de salud mental, física y balance vida-trabajo.
                      </p>
                      <div className="flex justify-between text-xs">
                        <span className="text-orange-600">Participación: 85%</span>
                        <span className="text-orange-600">NPS: +67</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Análisis de sentimiento */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="sentiment-analysis-title">Análisis de Sentimiento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600 mb-2" data-testid="positive-sentiment">72%</div>
                      <div className="text-sm text-muted-foreground mb-4">Sentimiento Positivo</div>
                      <div className="h-2 bg-green-100 rounded-full">
                        <div className="h-2 bg-green-600 rounded-full" style={{ width: '72%' }}></div>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl font-bold text-yellow-600 mb-2" data-testid="neutral-sentiment">22%</div>
                      <div className="text-sm text-muted-foreground mb-4">Sentimiento Neutral</div>
                      <div className="h-2 bg-yellow-100 rounded-full">
                        <div className="h-2 bg-yellow-600 rounded-full" style={{ width: '22%' }}></div>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-600 mb-2" data-testid="negative-sentiment">6%</div>
                      <div className="text-sm text-muted-foreground mb-4">Sentimiento Negativo</div>
                      <div className="h-2 bg-red-100 rounded-full">
                        <div className="h-2 bg-red-600 rounded-full" style={{ width: '6%' }}></div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-semibold text-foreground mb-3" data-testid="trending-topics-title">
                      Temas Trending
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" data-testid="topic-worklife">work-life balance</Badge>
                      <Badge variant="secondary" data-testid="topic-growth">crecimiento profesional</Badge>
                      <Badge variant="secondary" data-testid="topic-recognition">reconocimiento</Badge>
                      <Badge variant="secondary" data-testid="topic-innovation">innovación</Badge>
                      <Badge variant="secondary" data-testid="topic-team">trabajo en equipo</Badge>
                      <Badge variant="secondary" data-testid="topic-leadership">liderazgo</Badge>
                      <Badge variant="secondary" data-testid="topic-feedback">feedback</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
