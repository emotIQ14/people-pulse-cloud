import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Target, Loader2, MapPin } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function SkillPathfinderPage() {
  const [employeeProfile, setEmployeeProfile] = useState({
    name: "",
    currentRole: "",
    skills: "",
    goals: "",
    experience: ""
  });
  const [pathfinderResult, setPathfinderResult] = useState<any>(null);
  const { toast } = useToast();

  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "SkillPathfinder")
  });

  const pathfinderMutation = useMutation({
    mutationFn: async (profile: typeof employeeProfile) => {
      if (!module) throw new Error("Module not found");
      
      const content = `
        Perfil del empleado:
        Nombre: ${profile.name}
        Rol actual: ${profile.currentRole}
        Habilidades actuales: ${profile.skills}
        Objetivos profesionales: ${profile.goals}
        Experiencia: ${profile.experience}
      `;
      
      const response = await apiRequest("POST", `/api/modules/${module.id}/analyze`, {
        content,
        context: "Create a personalized skill development path and competency mapping for this employee profile"
      });
      return response.json();
    },
    onSuccess: (data) => {
      setPathfinderResult(data);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create skill path",
        variant: "destructive"
      });
    }
  });

  const handleCreatePath = () => {
    if (!employeeProfile.name || !employeeProfile.currentRole || !employeeProfile.goals) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios (nombre, rol actual y objetivos)",
        variant: "destructive"
      });
      return;
    }
    pathfinderMutation.mutate(employeeProfile);
  };

  return (
    <>
      <Header 
        title="SkillPathfinder" 
        description="Mapeo de competencias y rutas de desarrollo profesional"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-green-600" />
                <span>Mapeo de Competencias y Desarrollo</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Crea rutas de desarrollo personalizadas para empleados basadas en sus habilidades actuales, 
                objetivos profesionales y necesidades de la organización. Identifica brechas de competencias 
                y recomienda programas de capacitación específicos.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="create-path" className="space-y-4">
            <TabsList>
              <TabsTrigger value="create-path" data-testid="tab-create-path">Crear Ruta</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="create-path" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Formulario de perfil */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="employee-profile-title">Perfil del Empleado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre del empleado *</Label>
                      <Input
                        id="name"
                        value={employeeProfile.name}
                        onChange={(e) => setEmployeeProfile(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Nombre completo"
                        data-testid="input-name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="currentRole">Rol actual *</Label>
                      <Input
                        id="currentRole"
                        value={employeeProfile.currentRole}
                        onChange={(e) => setEmployeeProfile(prev => ({ ...prev, currentRole: e.target.value }))}
                        placeholder="Desarrollador Senior, Analista de Marketing, etc."
                        data-testid="input-current-role"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="skills">Habilidades actuales</Label>
                      <Textarea
                        id="skills"
                        value={employeeProfile.skills}
                        onChange={(e) => setEmployeeProfile(prev => ({ ...prev, skills: e.target.value }))}
                        placeholder="Lista las habilidades técnicas y blandas actuales..."
                        className="min-h-[80px] resize-none"
                        data-testid="input-skills"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="goals">Objetivos profesionales *</Label>
                      <Textarea
                        id="goals"
                        value={employeeProfile.goals}
                        onChange={(e) => setEmployeeProfile(prev => ({ ...prev, goals: e.target.value }))}
                        placeholder="Describe los objetivos de carrera a corto y largo plazo..."
                        className="min-h-[80px] resize-none"
                        data-testid="input-goals"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="experience">Experiencia relevante</Label>
                      <Textarea
                        id="experience"
                        value={employeeProfile.experience}
                        onChange={(e) => setEmployeeProfile(prev => ({ ...prev, experience: e.target.value }))}
                        placeholder="Años de experiencia, proyectos relevantes, logros..."
                        className="min-h-[80px] resize-none"
                        data-testid="input-experience"
                      />
                    </div>

                    <Button
                      onClick={handleCreatePath}
                      disabled={pathfinderMutation.isPending}
                      className="w-full"
                      data-testid="create-path-button"
                    >
                      {pathfinderMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Creando ruta...
                        </>
                      ) : (
                        "Crear Ruta de Desarrollo"
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Ruta de desarrollo */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="development-path-title">Ruta de Desarrollo</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pathfinderResult ? (
                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-foreground mb-3 flex items-center space-x-2">
                            <MapPin className="w-4 h-4 text-green-600" />
                            <span data-testid="analysis-summary">Análisis del Perfil</span>
                          </h4>
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                            {pathfinderResult.analysis}
                          </p>
                        </div>

                        {pathfinderResult.recommendations && pathfinderResult.recommendations.length > 0 && (
                          <div>
                            <h4 className="font-semibold text-foreground mb-3" data-testid="development-recommendations-title">
                              Plan de Desarrollo Recomendado
                            </h4>
                            <div className="space-y-3">
                              {pathfinderResult.recommendations.map((rec: string, index: number) => (
                                <div 
                                  key={index} 
                                  className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg"
                                  data-testid={`development-step-${index}`}
                                >
                                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-xs font-medium text-green-600">{index + 1}</span>
                                  </div>
                                  <p className="text-sm text-foreground">{rec}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {pathfinderResult.metadata && (
                          <div className="pt-4 border-t space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Viabilidad del plan:</span>
                              <span 
                                className="font-medium text-accent"
                                data-testid="confidence-score"
                              >
                                {Math.round((pathfinderResult.confidence || 0) * 100)}%
                              </span>
                            </div>
                            
                            {pathfinderResult.metadata.timeline && (
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Tiempo estimado:</span>
                                <span className="font-medium text-foreground">
                                  {pathfinderResult.metadata.timeline}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground py-12">
                        <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p data-testid="no-path-message">
                          La ruta de desarrollo personalizada aparecerá aquí una vez que completes el perfil del empleado.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
