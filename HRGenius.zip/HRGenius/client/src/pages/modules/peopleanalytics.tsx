import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, TrendingUp, Users, AlertTriangle } from "lucide-react";

export default function PeopleAnalyticsPage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "PeopleAnalytics Pro")
  });

  return (
    <>
      <Header 
        title="PeopleAnalytics Pro" 
        description="Análisis avanzado de datos y métricas de talento humano"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-purple-600" />
                <span>Análisis de Datos de Talento Humano</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Utiliza inteligencia artificial para analizar métricas de empleados, patrones de retención, 
                productividad y engagement. Genera insights predictivos y recomendaciones basadas en datos 
                para optimizar la gestión del talento.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview" data-testid="tab-overview">Resumen Analítico</TabsTrigger>
              <TabsTrigger value="metrics" data-testid="tab-metrics">Métricas Clave</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Insights principales */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="key-insights-title">Insights Principales</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900" data-testid="insight-retention">
                            Tendencia de Retención Positiva
                          </h4>
                          <p className="text-xs text-blue-700 mt-1">
                            La tasa de retención ha mejorado un 5% en los últimos 6 meses. 
                            Los programas de desarrollo profesional muestran impacto positivo.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Users className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-green-900" data-testid="insight-engagement">
                            Alto Nivel de Engagement
                          </h4>
                          <p className="text-xs text-green-700 mt-1">
                            El 89% de los empleados reportan satisfacción laboral. 
                            Los equipos remotos mantienen niveles similares a presenciales.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-yellow-900" data-testid="insight-attention-needed">
                            Área de Atención: IT
                          </h4>
                          <p className="text-xs text-yellow-700 mt-1">
                            El departamento de IT muestra indicadores de estrés elevados. 
                            Se recomienda evaluación de carga de trabajo y recursos.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Predicciones y recomendaciones */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="predictions-title">Predicciones y Recomendaciones</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2" data-testid="ai-predictions">
                        Predicciones basadas en IA
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start space-x-2" data-testid="prediction-turnover">
                          <span className="text-accent font-medium">•</span>
                          <span>Riesgo de rotación del 12% en Q1 2025 si no se toman acciones correctivas</span>
                        </li>
                        <li className="flex items-start space-x-2" data-testid="prediction-growth">
                          <span className="text-accent font-medium">•</span>
                          <span>Crecimiento esperado del 8% en productividad con implementación de nuevas herramientas</span>
                        </li>
                        <li className="flex items-start space-x-2" data-testid="prediction-hiring">
                          <span className="text-accent font-medium">•</span>
                          <span>Necesidad proyectada de 15 nuevas contrataciones en el área técnica para Q2</span>
                        </li>
                      </ul>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-2" data-testid="ai-recommendations">
                        Recomendaciones Estratégicas
                      </h4>
                      <ul className="space-y-2 text-sm text-muted-foreground">
                        <li className="flex items-start space-x-2" data-testid="recommendation-training">
                          <span className="text-green-600 font-medium">✓</span>
                          <span>Implementar programa de capacitación en tecnologías emergentes</span>
                        </li>
                        <li className="flex items-start space-x-2" data-testid="recommendation-wellness">
                          <span className="text-green-600 font-medium">✓</span>
                          <span>Reforzar programas de bienestar y equilibrio trabajo-vida</span>
                        </li>
                        <li className="flex items-start space-x-2" data-testid="recommendation-mentorship">
                          <span className="text-green-600 font-medium">✓</span>
                          <span>Establecer programa de mentoría para empleados junior</span>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="metrics" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Métricas clave */}
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl font-bold text-foreground" data-testid="metric-retention">94.2%</div>
                    <div className="text-sm text-muted-foreground">Tasa de Retención</div>
                    <div className="text-xs text-green-600 mt-1">+1.2% vs anterior</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl font-bold text-foreground" data-testid="metric-engagement">89%</div>
                    <div className="text-sm text-muted-foreground">Engagement Score</div>
                    <div className="text-xs text-green-600 mt-1">+5% este mes</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl font-bold text-foreground" data-testid="metric-productivity">112%</div>
                    <div className="text-sm text-muted-foreground">Índice Productividad</div>
                    <div className="text-xs text-green-600 mt-1">Meta superada</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl font-bold text-foreground" data-testid="metric-satisfaction">4.6/5</div>
                    <div className="text-sm text-muted-foreground">Satisfacción Laboral</div>
                    <div className="text-xs text-green-600 mt-1">Excelente</div>
                  </CardContent>
                </Card>
              </div>

              {/* Análisis detallado */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="detailed-analysis-title">Análisis Detallado por Departamento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium" data-testid="dept-engineering">Ingeniería</div>
                        <div className="text-sm text-muted-foreground">125 empleados</div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-600 font-medium">96% retención</div>
                        <div className="text-sm text-muted-foreground">Alto rendimiento</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium" data-testid="dept-sales">Ventas</div>
                        <div className="text-sm text-muted-foreground">89 empleados</div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-600 font-medium">93% retención</div>
                        <div className="text-sm text-muted-foreground">Objetivos alcanzados</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <div className="font-medium" data-testid="dept-marketing">Marketing</div>
                        <div className="text-sm text-muted-foreground">67 empleados</div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-600 font-medium">91% retención</div>
                        <div className="text-sm text-muted-foreground">Innovación alta</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div>
                        <div className="font-medium" data-testid="dept-it">Tecnología</div>
                        <div className="text-sm text-muted-foreground">78 empleados</div>
                      </div>
                      <div className="text-right">
                        <div className="text-yellow-600 font-medium">87% retención</div>
                        <div className="text-sm text-muted-foreground">Requiere atención</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
