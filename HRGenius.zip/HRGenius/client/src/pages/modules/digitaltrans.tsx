import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Zap, Cog, Rocket, Target, TrendingUp, Clock, CheckCircle } from "lucide-react";

export default function DigitalTransPage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "DigitalTrans")
  });

  return (
    <>
      <Header 
        title="DigitalTrans" 
        description="Estrategias de transformación digital específicas para el área de recursos humanos"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Lightbulb className="w-5 h-5 text-indigo-600" />
                <span>Transformación Digital en RRHH</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Diseña e implementa estrategias de digitalización específicas para recursos humanos. 
                Identifica oportunidades de automatización, optimización de procesos y adopción 
                de tecnologías emergentes para modernizar la gestión del talento.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="initiatives" className="space-y-4">
            <TabsList>
              <TabsTrigger value="initiatives" data-testid="tab-initiatives">Iniciativas Activas</TabsTrigger>
              <TabsTrigger value="roadmap" data-testid="tab-roadmap">Hoja de Ruta</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="initiatives" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Progreso general */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="digital-progress-title">Progreso de Transformación Digital</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg">
                      <Rocket className="w-12 h-12 text-indigo-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-indigo-600" data-testid="overall-progress">78%</div>
                      <div className="text-sm text-indigo-700">Transformación Completada</div>
                      <Progress value={78} className="mt-3 h-2" />
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="automation-progress-label">Automatización de Procesos</span>
                          <span className="text-sm text-muted-foreground">85%</span>
                        </div>
                        <Progress value={85} className="h-2" data-testid="automation-progress" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="analytics-progress-label">Analytics Avanzado</span>
                          <span className="text-sm text-muted-foreground">72%</span>
                        </div>
                        <Progress value={72} className="h-2" data-testid="analytics-progress" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="ai-integration-progress-label">Integración IA</span>
                          <span className="text-sm text-muted-foreground">65%</span>
                        </div>
                        <Progress value={65} className="h-2" data-testid="ai-integration-progress" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium" data-testid="self-service-progress-label">Self-Service Empleados</span>
                          <span className="text-sm text-muted-foreground">90%</span>
                        </div>
                        <Progress value={90} className="h-2" data-testid="self-service-progress" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Iniciativas en curso */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="active-initiatives-title">Iniciativas en Curso</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <Zap className="w-5 h-5 text-blue-600" />
                          <div>
                            <h4 className="font-medium text-blue-900" data-testid="initiative-chatbots">Chatbots de Soporte HR</h4>
                            <p className="text-sm text-blue-700">Automatización de consultas frecuentes</p>
                          </div>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800" data-testid="initiative-chatbots-status">En desarrollo</Badge>
                      </div>
                      <Progress value={75} className="h-2" />
                      <div className="flex justify-between text-xs text-blue-600 mt-1">
                        <span>75% completado</span>
                        <span>Finaliza: Feb 2025</span>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <Target className="w-5 h-5 text-green-600" />
                          <div>
                            <h4 className="font-medium text-green-900" data-testid="initiative-predictive">Analytics Predictivo</h4>
                            <p className="text-sm text-green-700">Predicción de rotación y performance</p>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800" data-testid="initiative-predictive-status">Implementando</Badge>
                      </div>
                      <Progress value={60} className="h-2" />
                      <div className="flex justify-between text-xs text-green-600 mt-1">
                        <span>60% completado</span>
                        <span>Finaliza: Mar 2025</span>
                      </div>
                    </div>

                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <Cog className="w-5 h-5 text-purple-600" />
                          <div>
                            <h4 className="font-medium text-purple-900" data-testid="initiative-workflow">Workflow Automation</h4>
                            <p className="text-sm text-purple-700">Automatización de onboarding</p>
                          </div>
                        </div>
                        <Badge className="bg-purple-100 text-purple-800" data-testid="initiative-workflow-status">Planificando</Badge>
                      </div>
                      <Progress value={25} className="h-2" />
                      <div className="flex justify-between text-xs text-purple-600 mt-1">
                        <span>25% completado</span>
                        <span>Finaliza: Abr 2025</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Métricas de impacto */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="impact-metrics-title">Métricas de Impacto</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                      <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-blue-600" data-testid="efficiency-gain">+35%</div>
                      <div className="text-sm text-blue-700">Eficiencia Operacional</div>
                    </div>

                    <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                      <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600" data-testid="time-saved">-40%</div>
                      <div className="text-sm text-green-700">Tiempo en Tareas Manuales</div>
                    </div>

                    <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                      <Target className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-purple-600" data-testid="accuracy-improvement">+50%</div>
                      <div className="text-sm text-purple-700">Precisión en Predicciones</div>
                    </div>

                    <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg">
                      <CheckCircle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-orange-600" data-testid="satisfaction-score">92%</div>
                      <div className="text-sm text-orange-700">Satisfacción del Usuario</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="roadmap" className="space-y-4">
              <div className="space-y-6">
                {/* Hoja de ruta trimestral */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="roadmap-title">Hoja de Ruta 2025</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Q1 2025 */}
                      <div className="relative">
                        <div className="flex items-center mb-4">
                          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            Q1
                          </div>
                          <h3 className="ml-3 text-lg font-semibold text-foreground" data-testid="q1-title">
                            Enero - Marzo 2025
                          </h3>
                        </div>
                        <div className="ml-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                            <div className="font-medium text-blue-900" data-testid="q1-item-1">Finalizar Chatbots HR</div>
                            <div className="text-sm text-blue-700">Despliegue en producción</div>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                            <div className="font-medium text-green-900" data-testid="q1-item-2">Analytics Predictivo</div>
                            <div className="text-sm text-green-700">Modelo de rotación</div>
                          </div>
                          <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                            <div className="font-medium text-purple-900" data-testid="q1-item-3">Mobile App HR</div>
                            <div className="text-sm text-purple-700">Fase de desarrollo</div>
                          </div>
                        </div>
                      </div>

                      {/* Q2 2025 */}
                      <div className="relative">
                        <div className="flex items-center mb-4">
                          <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            Q2
                          </div>
                          <h3 className="ml-3 text-lg font-semibold text-foreground" data-testid="q2-title">
                            Abril - Junio 2025
                          </h3>
                        </div>
                        <div className="ml-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                            <div className="font-medium text-indigo-900" data-testid="q2-item-1">Workflow Automatizado</div>
                            <div className="text-sm text-indigo-700">Onboarding y offboarding</div>
                          </div>
                          <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                            <div className="font-medium text-orange-900" data-testid="q2-item-2">IA Generativa</div>
                            <div className="text-sm text-orange-700">Creación de contenido HR</div>
                          </div>
                          <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                            <div className="font-medium text-teal-900" data-testid="q2-item-3">Dashboard Ejecutivo</div>
                            <div className="text-sm text-teal-700">Métricas en tiempo real</div>
                          </div>
                        </div>
                      </div>

                      {/* Q3 2025 */}
                      <div className="relative">
                        <div className="flex items-center mb-4">
                          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            Q3
                          </div>
                          <h3 className="ml-3 text-lg font-semibold text-foreground" data-testid="q3-title">
                            Julio - Septiembre 2025
                          </h3>
                        </div>
                        <div className="ml-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="p-3 bg-pink-50 rounded-lg border border-pink-200">
                            <div className="font-medium text-pink-900" data-testid="q3-item-1">Blockchain Credentials</div>
                            <div className="text-sm text-pink-700">Certificaciones verificables</div>
                          </div>
                          <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                            <div className="font-medium text-yellow-900" data-testid="q3-item-2">VR Training</div>
                            <div className="text-sm text-yellow-700">Capacitación inmersiva</div>
                          </div>
                          <div className="p-3 bg-cyan-50 rounded-lg border border-cyan-200">
                            <div className="font-medium text-cyan-900" data-testid="q3-item-3">IoT Workplace</div>
                            <div className="text-sm text-cyan-700">Sensores de bienestar</div>
                          </div>
                        </div>
                      </div>

                      {/* Q4 2025 */}
                      <div className="relative">
                        <div className="flex items-center mb-4">
                          <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            Q4
                          </div>
                          <h3 className="ml-3 text-lg font-semibold text-foreground" data-testid="q4-title">
                            Octubre - Diciembre 2025
                          </h3>
                        </div>
                        <div className="ml-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                            <div className="font-medium text-red-900" data-testid="q4-item-1">AI Ethics Framework</div>
                            <div className="text-sm text-red-700">Gobernanza de IA</div>
                          </div>
                          <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                            <div className="font-medium text-emerald-900" data-testid="q4-item-2">Quantum Analytics</div>
                            <div className="text-sm text-emerald-700">Análisis de próxima generación</div>
                          </div>
                          <div className="p-3 bg-violet-50 rounded-lg border border-violet-200">
                            <div className="font-medium text-violet-900" data-testid="q4-item-3">Integration Platform</div>
                            <div className="text-sm text-violet-700">Ecosistema unificado</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Recursos y presupuesto */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle data-testid="budget-allocation-title">Asignación de Presupuesto</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm" data-testid="budget-ai-tools">Herramientas de IA</span>
                          <span className="font-medium">40%</span>
                        </div>
                        <Progress value={40} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm" data-testid="budget-infrastructure">Infraestructura</span>
                          <span className="font-medium">25%</span>
                        </div>
                        <Progress value={25} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm" data-testid="budget-training">Capacitación</span>
                          <span className="font-medium">20%</span>
                        </div>
                        <Progress value={20} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm" data-testid="budget-consulting">Consultoría</span>
                          <span className="font-medium">15%</span>
                        </div>
                        <Progress value={15} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle data-testid="success-factors-title">Factores Críticos de Éxito</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-medium" data-testid="success-leadership">Liderazgo Comprometido</div>
                          <div className="text-sm text-muted-foreground">Apoyo ejecutivo continuo</div>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-medium" data-testid="success-change-management">Gestión del Cambio</div>
                          <div className="text-sm text-muted-foreground">Adopción gradual y capacitación</div>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-medium" data-testid="success-data-quality">Calidad de Datos</div>
                          <div className="text-sm text-muted-foreground">Datos limpios y actualizados</div>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <div className="font-medium" data-testid="success-security">Seguridad y Privacidad</div>
                          <div className="text-sm text-muted-foreground">Protección de información sensible</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
