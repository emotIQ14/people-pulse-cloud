import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function WritingStylePage() {
  const [analysisText, setAnalysisText] = useState("");
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const { toast } = useToast();

  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "WritingStyle")
  });

  const analysisMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!module) throw new Error("Module not found");
      const response = await apiRequest("POST", `/api/modules/${module.id}/analyze`, {
        content,
        context: "Analyze the writing style and provide recommendations for improvement"
      });
      return response.json();
    },
    onSuccess: (data) => {
      setAnalysisResult(data);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to analyze content",
        variant: "destructive"
      });
    }
  });

  const handleAnalyze = () => {
    if (!analysisText.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingresa un texto para analizar",
        variant: "destructive"
      });
      return;
    }
    analysisMutation.mutate(analysisText);
  };

  return (
    <>
      <Header 
        title="WritingStyle" 
        description="Análisis y mejora del estilo de escritura corporativa"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>Análisis de Estilo de Escritura</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Este módulo utiliza IA especializada para analizar documentos corporativos, emails, políticas y comunicaciones, 
                proporcionando recomendaciones para mejorar la claridad, tono profesional y consistencia de marca.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="analyze" className="space-y-4">
            <TabsList>
              <TabsTrigger value="analyze" data-testid="tab-analyze">Analizar Texto</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="analyze" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Input de análisis */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="analysis-input-title">Texto a Analizar</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      value={analysisText}
                      onChange={(e) => setAnalysisText(e.target.value)}
                      placeholder="Pega aquí el texto que quieres analizar (email, documento, política, etc.)"
                      className="min-h-[300px] resize-none"
                      data-testid="analysis-input"
                    />
                    <Button
                      onClick={handleAnalyze}
                      disabled={analysisMutation.isPending || !analysisText.trim()}
                      className="w-full"
                      data-testid="analyze-button"
                    >
                      {analysisMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analizando...
                        </>
                      ) : (
                        "Analizar Estilo de Escritura"
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Resultados del análisis */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="analysis-results-title">Resultados del Análisis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {analysisResult ? (
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold text-foreground mb-2" data-testid="analysis-summary">
                            Análisis
                          </h4>
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                            {analysisResult.analysis}
                          </p>
                        </div>

                        {analysisResult.recommendations && analysisResult.recommendations.length > 0 && (
                          <div>
                            <h4 className="font-semibold text-foreground mb-2" data-testid="recommendations-title">
                              Recomendaciones
                            </h4>
                            <ul className="space-y-2">
                              {analysisResult.recommendations.map((rec: string, index: number) => (
                                <li 
                                  key={index} 
                                  className="text-sm text-muted-foreground flex items-start space-x-2"
                                  data-testid={`recommendation-${index}`}
                                >
                                  <span className="text-accent font-medium">•</span>
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        <div className="pt-4 border-t">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Confianza del análisis:</span>
                            <span 
                              className="font-medium text-accent"
                              data-testid="confidence-score"
                            >
                              {Math.round((analysisResult.confidence || 0) * 100)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground py-12">
                        <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p data-testid="no-analysis-message">
                          Los resultados del análisis aparecerán aquí una vez que analices un texto.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
