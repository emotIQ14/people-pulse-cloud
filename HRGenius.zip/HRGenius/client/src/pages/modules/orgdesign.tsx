import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, GitBranch, Target, TrendingUp } from "lucide-react";

export default function OrgDesignPage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "OrgDesign")
  });

  return (
    <>
      <Header 
        title="OrgDesign" 
        description="Diseño y optimización de estructura organizacional"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <GitBranch className="w-5 h-5 text-orange-600" />
                <span>Diseño Organizacional Inteligente</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Analiza y optimiza la estructura organizacional para mejorar la eficiencia, colaboración y escalabilidad. 
                Utiliza IA para identificar oportunidades de reorganización, eliminación de silos y mejora de flujos de trabajo.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="structure" className="space-y-4">
            <TabsList>
              <TabsTrigger value="structure" data-testid="tab-structure">Estructura Actual</TabsTrigger>
              <TabsTrigger value="optimization" data-testid="tab-optimization">Optimizaciones</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="structure" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Análisis estructural */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="structural-analysis-title">Análisis Estructural</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-blue-600" />
                          <span className="font-medium" data-testid="level-executives">Nivel Ejecutivo</span>
                        </div>
                        <span className="text-sm text-muted-foreground">8 personas</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="level-managers">Gerentes/Directores</span>
                        </div>
                        <span className="text-sm text-muted-foreground">24 personas</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-purple-600" />
                          <span className="font-medium" data-testid="level-leads">Líderes de Equipo</span>
                        </div>
                        <span className="text-sm text-muted-foreground">45 personas</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-orange-600" />
                          <span className="font-medium" data-testid="level-individual">Contribuidores Individuales</span>
                        </div>
                        <span className="text-sm text-muted-foreground">1,170 personas</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="span-control-title">
                        Análisis de Span of Control
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Promedio de reportes directos:</span>
                          <span className="font-medium" data-testid="avg-reports">8.5</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Niveles jerárquicos:</span>
                          <span className="font-medium" data-testid="hierarchy-levels">4</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Eficiencia organizacional:</span>
                          <span className="font-medium text-green-600" data-testid="org-efficiency">85%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Departamentos y funciones */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="departments-title">Departamentos y Funciones</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 bg-blue-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-blue-600" data-testid="dept-tech-count">203</div>
                          <div className="text-sm text-blue-700">Tecnología</div>
                        </div>

                        <div className="p-3 bg-green-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-green-600" data-testid="dept-sales-count">156</div>
                          <div className="text-sm text-green-700">Ventas</div>
                        </div>

                        <div className="p-3 bg-purple-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-purple-600" data-testid="dept-marketing-count">89</div>
                          <div className="text-sm text-purple-700">Marketing</div>
                        </div>

                        <div className="p-3 bg-orange-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-orange-600" data-testid="dept-operations-count">124</div>
                          <div className="text-sm text-orange-700">Operaciones</div>
                        </div>

                        <div className="p-3 bg-red-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-red-600" data-testid="dept-finance-count">67</div>
                          <div className="text-sm text-red-700">Finanzas</div>
                        </div>

                        <div className="p-3 bg-teal-50 rounded-lg text-center">
                          <div className="text-xl font-bold text-teal-600" data-testid="dept-hr-count">45</div>
                          <div className="text-sm text-teal-700">Recursos Humanos</div>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-semibold text-foreground mb-3" data-testid="collaboration-index-title">
                          Índice de Colaboración
                        </h4>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Tecnología - Producto:</span>
                            <span className="text-green-600 font-medium">Alta</span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Ventas - Marketing:</span>
                            <span className="text-green-600 font-medium">Alta</span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Operaciones - Finanzas:</span>
                            <span className="text-yellow-600 font-medium">Media</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="optimization" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Oportunidades de mejora */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="improvement-opportunities-title">Oportunidades de Mejora</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Target className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900" data-testid="opportunity-flatten">
                            Aplanar Estructura
                          </h4>
                          <p className="text-xs text-blue-700 mt-1">
                            Reducir un nivel jerárquico en el área de operaciones podría mejorar 
                            la velocidad de toma de decisiones en un 25%.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Users className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-green-900" data-testid="opportunity-cross-functional">
                            Equipos Multifuncionales
                          </h4>
                          <p className="text-xs text-green-700 mt-1">
                            Crear equipos producto-tecnología-diseño integrados podría 
                            acelerar el time-to-market en un 30%.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <GitBranch className="w-5 h-5 text-purple-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-purple-900" data-testid="opportunity-centers">
                            Centros de Excelencia
                          </h4>
                          <p className="text-xs text-purple-700 mt-1">
                            Establecer CoEs para Data Science y UX/UI podría mejorar 
                            la calidad y consistencia en toda la organización.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Métricas de impacto */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="impact-metrics-title">Métricas de Impacto Proyectadas</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <TrendingUp className="w-5 h-5 text-green-600" />
                          <span className="font-medium" data-testid="metric-efficiency">Eficiencia Operacional</span>
                        </div>
                        <span className="text-green-600 font-medium">+20%</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Target className="w-5 h-5 text-blue-600" />
                          <span className="font-medium" data-testid="metric-decision-speed">Velocidad de Decisiones</span>
                        </div>
                        <span className="text-blue-600 font-medium">+35%</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Users className="w-5 h-5 text-purple-600" />
                          <span className="font-medium" data-testid="metric-collaboration">Colaboración Interdepartamental</span>
                        </div>
                        <span className="text-purple-600 font-medium">+40%</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <GitBranch className="w-5 h-5 text-orange-600" />
                          <span className="font-medium" data-testid="metric-innovation">Capacidad de Innovación</span>
                        </div>
                        <span className="text-orange-600 font-medium">+25%</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="implementation-plan-title">
                        Plan de Implementación
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fase 1 (Mes 1-2):</span>
                          <span className="font-medium">Reorganización operaciones</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fase 2 (Mes 3-4):</span>
                          <span className="font-medium">Equipos multifuncionales</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fase 3 (Mes 5-6):</span>
                          <span className="font-medium">Centros de excelencia</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
