import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import AiChat from "@/components/ui/ai-chat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Crown, TrendingUp, Users, Target, BarChart3, Lightbulb, AlertTriangle, CheckCircle, Globe, Zap } from "lucide-react";

export default function ChroPage() {
  const { data: module } = useQuery({
    queryKey: ["/api/modules"],
    select: (data) => (data as any)?.find((m: any) => m.name === "CHRO Advisor")
  });

  return (
    <>
      <Header 
        title="CHRO Advisor" 
        description="Asesoría estratégica para directivos de RRHH con insights y recomendaciones ejecutivas"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Información del módulo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Crown className="w-5 h-5 text-teal-600" />
                <span>Asesoría Estratégica Ejecutiva</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Proporciona insights estratégicos y recomendaciones de alto nivel para directivos de RRHH. 
                Analiza tendencias del mercado, benchmarking competitivo y oportunidades de transformación 
                organizacional para impulsar la agenda estratégica de talento humano.
              </p>
            </CardContent>
          </Card>

          <Tabs defaultValue="strategic" className="space-y-4">
            <TabsList>
              <TabsTrigger value="strategic" data-testid="tab-strategic">Dashboard Estratégico</TabsTrigger>
              <TabsTrigger value="workforce" data-testid="tab-workforce">Planificación de Fuerza Laboral</TabsTrigger>
              <TabsTrigger value="benchmarking" data-testid="tab-benchmarking">Benchmarking Competitivo</TabsTrigger>
              <TabsTrigger value="chat" data-testid="tab-chat">Chat Interactivo</TabsTrigger>
            </TabsList>

            <TabsContent value="strategic" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* KPIs estratégicos */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="strategic-kpis-title">KPIs Estratégicos</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center p-6 bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg">
                      <Crown className="w-12 h-12 text-teal-600 mx-auto mb-3" />
                      <div className="text-3xl font-bold text-teal-600" data-testid="strategic-maturity">8.5/10</div>
                      <div className="text-sm text-teal-700">Madurez HR Estratégica</div>
                      <Badge className="mt-2 bg-teal-100 text-teal-800" data-testid="maturity-level">
                        Avanzado
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-blue-600" data-testid="revenue-per-employee">$185K</div>
                        <div className="text-sm text-blue-700">Revenue/Employee</div>
                      </div>

                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-green-600" data-testid="talent-density">4.2/5</div>
                        <div className="text-sm text-green-700">Talent Density</div>
                      </div>

                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <Target className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-purple-600" data-testid="strategic-alignment">92%</div>
                        <div className="text-sm text-purple-700">Strategic Alignment</div>
                      </div>

                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <Lightbulb className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                        <div className="text-xl font-bold text-orange-600" data-testid="innovation-index">87%</div>
                        <div className="text-sm text-orange-700">Innovation Index</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Prioridades ejecutivas */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="executive-priorities-title">Prioridades Ejecutivas 2025</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-red-600 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                            <span className="font-medium text-red-900" data-testid="priority-transformation">Transformación Digital HR</span>
                          </div>
                          <Badge className="bg-red-100 text-red-800">Crítico</Badge>
                        </div>
                        <p className="text-sm text-red-700 ml-9">
                          Acelerar adopción de IA y automatización para escalar operaciones HR.
                        </p>
                      </div>

                      <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                            <span className="font-medium text-orange-900" data-testid="priority-talent">Atracción de Talento Top</span>
                          </div>
                          <Badge className="bg-orange-100 text-orange-800">Alto</Badge>
                        </div>
                        <p className="text-sm text-orange-700 ml-9">
                          Fortalecer employer branding y estrategias de reclutamiento competitivas.
                        </p>
                      </div>

                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                            <span className="font-medium text-blue-900" data-testid="priority-culture">Evolución Cultural</span>
                          </div>
                          <Badge className="bg-blue-100 text-blue-800">Medio</Badge>
                        </div>
                        <p className="text-sm text-blue-700 ml-9">
                          Adaptar cultura organizacional para trabajo híbrido y nuevas generaciones.
                        </p>
                      </div>

                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">4</div>
                            <span className="font-medium text-green-900" data-testid="priority-development">Desarrollo Liderazgo</span>
                          </div>
                          <Badge className="bg-green-100 text-green-800">Medio</Badge>
                        </div>
                        <p className="text-sm text-green-700 ml-9">
                          Invertir en pipeline de líderes para crecimiento futuro de la organización.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Insights estratégicos */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="strategic-insights-title">Insights Estratégicos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <BarChart3 className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900" data-testid="insight-market-position">Posición de Mercado Fuerte</h4>
                          <p className="text-xs text-blue-700 mt-1">
                            La organización se posiciona en el top 15% del sector en métricas 
                            de talento. Oportunidad para liderar mejores prácticas.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-green-900" data-testid="insight-growth-ready">Preparado para Crecimiento</h4>
                          <p className="text-xs text-green-700 mt-1">
                            La infraestructura HR actual puede soportar 30% de crecimiento 
                            adicional sin cambios estructurales significativos.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-yellow-900" data-testid="insight-skill-gap">Brecha de Habilidades Futuras</h4>
                          <p className="text-xs text-yellow-700 mt-1">
                            35% de roles actuales requerirán nuevas habilidades en los próximos 
                            3 años. Iniciar reskilling proactivo.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="workforce" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Proyecciones de fuerza laboral */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="workforce-projections-title">Proyecciones de Fuerza Laboral</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-3" data-testid="growth-scenario-title">Escenario de Crecimiento Agresivo</h4>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <div className="text-2xl font-bold text-blue-600" data-testid="current-headcount">1,247</div>
                            <div className="text-sm text-blue-700">Actual</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-indigo-600" data-testid="projected-headcount">1,850</div>
                            <div className="text-sm text-indigo-700">Meta 2026</div>
                          </div>
                        </div>
                        <div className="mt-3 text-xs text-blue-600">
                          +48% crecimiento en 18 meses | +603 nuevas contrataciones
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <span className="text-sm font-medium" data-testid="hiring-tech">Tecnología</span>
                          <div className="text-right">
                            <div className="text-sm font-medium text-blue-600">+180 personas</div>
                            <div className="text-xs text-muted-foreground">Engineering, Product, Data</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <span className="text-sm font-medium" data-testid="hiring-sales">Ventas & Marketing</span>
                          <div className="text-right">
                            <div className="text-sm font-medium text-green-600">+150 personas</div>
                            <div className="text-xs text-muted-foreground">Sales, Marketing, Success</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <span className="text-sm font-medium" data-testid="hiring-operations">Operaciones</span>
                          <div className="text-right">
                            <div className="text-sm font-medium text-purple-600">+120 personas</div>
                            <div className="text-xs text-muted-foreground">Finance, Ops, Legal</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <span className="text-sm font-medium" data-testid="hiring-support">Soporte & Enablement</span>
                          <div className="text-right">
                            <div className="text-sm font-medium text-orange-600">+153 personas</div>
                            <div className="text-xs text-muted-foreground">HR, IT, Admin</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Estrategia de talento */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="talent-strategy-title">Estrategia de Adquisición de Talento</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                        <div className="flex items-center space-x-3 mb-2">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium text-green-900" data-testid="strategy-internal">Movilidad Interna</span>
                        </div>
                        <div className="text-sm text-green-700 ml-8">
                          40% de posiciones senior cubiertas internamente
                        </div>
                        <div className="text-xs text-green-600 ml-8 mt-1">
                          Reducción de 60% en tiempo de contratación
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center space-x-3 mb-2">
                          <Globe className="w-5 h-5 text-blue-600" />
                          <span className="font-medium text-blue-900" data-testid="strategy-global">Talento Global</span>
                        </div>
                        <div className="text-sm text-blue-700 ml-8">
                          30% de contrataciones desde mercados internacionales
                        </div>
                        <div className="text-xs text-blue-600 ml-8 mt-1">
                          Acceso a pools de talento especializados
                        </div>
                      </div>

                      <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                        <div className="flex items-center space-x-3 mb-2">
                          <Zap className="w-5 h-5 text-purple-600" />
                          <span className="font-medium text-purple-900" data-testid="strategy-automation">Automatización Recruitng</span>
                        </div>
                        <div className="text-sm text-purple-700 ml-8">
                          IA para screening inicial y matching de candidatos
                        </div>
                        <div className="text-xs text-purple-600 ml-8 mt-1">
                          Reducción de 50% en tiempo de screening
                        </div>
                      </div>

                      <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <div className="flex items-center space-x-3 mb-2">
                          <Users className="w-5 h-5 text-orange-600" />
                          <span className="font-medium text-orange-900" data-testid="strategy-partnerships">Partnerships Académicos</span>
                        </div>
                        <div className="text-sm text-orange-700 ml-8">
                          Alianzas con top 10 universidades para talent pipeline
                        </div>
                        <div className="text-xs text-orange-600 ml-8 mt-1">
                          Pipeline de 200+ graduados anuales
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold text-foreground mb-3" data-testid="investment-requirements-title">
                        Inversiones Requeridas
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Plataforma ATS/CRM:</span>
                          <span className="font-medium" data-testid="investment-ats">$120K</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Employer Branding:</span>
                          <span className="font-medium" data-testid="investment-branding">$300K</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Recruitment Team:</span>
                          <span className="font-medium" data-testid="investment-team">$800K</span>
                        </div>
                        <div className="flex justify-between text-base font-semibold pt-2 border-t">
                          <span>Total Anual:</span>
                          <span className="text-teal-600" data-testid="investment-total">$1.22M</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="benchmarking" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Comparativa competitiva */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="competitive-benchmark-title">Benchmarking Competitivo</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
                        <h4 className="font-semibold text-green-900 mb-3" data-testid="our-position">Nuestra Posición</h4>
                        <div className="grid grid-cols-3 gap-3 text-center">
                          <div>
                            <div className="text-lg font-bold text-green-600" data-testid="rank-retention">Top 5%</div>
                            <div className="text-xs text-green-700">Retención</div>
                          </div>
                          <div>
                            <div className="text-lg font-bold text-green-600" data-testid="rank-engagement">Top 10%</div>
                            <div className="text-xs text-green-700">Engagement</div>
                          </div>
                          <div>
                            <div className="text-lg font-bold text-green-600" data-testid="rank-productivity">Top 15%</div>
                            <div className="text-xs text-green-700">Productividad</div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                          <div>
                            <div className="font-medium text-blue-900" data-testid="competitor-a">TechCorp A</div>
                            <div className="text-sm text-blue-700">Competidor directo</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-blue-600">85% retention</div>
                            <div className="text-xs text-blue-500">-9% vs nosotros</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                          <div>
                            <div className="font-medium text-yellow-900" data-testid="competitor-b">InnovateCorp</div>
                            <div className="text-sm text-yellow-700">Líder de sector</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-yellow-600">96% retention</div>
                            <div className="text-xs text-yellow-500">+2% vs nosotros</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                          <div>
                            <div className="font-medium text-purple-900" data-testid="competitor-c">StartupUnicorn</div>
                            <div className="text-sm text-purple-700">Disruptor emergente</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-purple-600">78% retention</div>
                            <div className="text-xs text-purple-500">-16% vs nosotros</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Mejores prácticas del mercado */}
                <Card>
                  <CardHeader>
                    <CardTitle data-testid="market-best-practices-title">Mejores Prácticas del Mercado</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="flex items-center space-x-3 mb-3">
                          <Target className="w-5 h-5 text-blue-600" />
                          <h4 className="font-medium text-blue-900" data-testid="practice-okrs">OKRs Cascadeados</h4>
                        </div>
                        <p className="text-sm text-blue-700 mb-2">
                          Implementación de objetivos alineados desde CEO hasta individual contributor.
                        </p>
                        <div className="flex justify-between text-xs">
                          <span className="text-blue-600">Adopción mercado: 78%</span>
                          <span className="text-blue-600">Nuestra adopción: 90%</span>
                        </div>
                      </div>

                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center space-x-3 mb-3">
                          <Lightbulb className="w-5 h-5 text-green-600" />
                          <h4 className="font-medium text-green-900" data-testid="practice-ai">IA en Talent Management</h4>
                        </div>
                        <p className="text-sm text-green-700 mb-2">
                          Uso de IA para matching, desarrollo de carrera y predicción de performance.
                        </p>
                        <div className="flex justify-between text-xs">
                          <span className="text-green-600">Adopción mercado: 35%</span>
                          <span className="text-green-600">Nuestra adopción: 65%</span>
                        </div>
                      </div>

                      <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                        <div className="flex items-center space-x-3 mb-3">
                          <Users className="w-5 h-5 text-orange-600" />
                          <h4 className="font-medium text-orange-900" data-testid="practice-diversity">Diversity & Inclusion</h4>
                        </div>
                        <p className="text-sm text-orange-700 mb-2">
                          Métricas específicas de D&I con accountability en todos los niveles.
                        </p>
                        <div className="flex justify-between text-xs">
                          <span className="text-orange-600">Adopción mercado: 85%</span>
                          <span className="text-orange-600">Nuestra adopción: 92%</span>
                        </div>
                      </div>

                      <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                        <div className="flex items-center space-x-3 mb-3">
                          <BarChart3 className="w-5 h-5 text-purple-600" />
                          <h4 className="font-medium text-purple-900" data-testid="practice-analytics">People Analytics</h4>
                        </div>
                        <p className="text-sm text-purple-700 mb-2">
                          Dashboard ejecutivo con métricas predictivas y insights accionables.
                        </p>
                        <div className="flex justify-between text-xs">
                          <span className="text-purple-600">Adopción mercado: 52%</span>
                          <span className="text-purple-600">Nuestra adopción: 88%</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recomendaciones estratégicas */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="strategic-recommendations-title">Recomendaciones Estratégicas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-semibold text-foreground" data-testid="short-term-title">Corto Plazo (3-6 meses)</h4>
                      <div className="space-y-3">
                        <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                          <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5">1</div>
                          <div>
                            <div className="font-medium text-blue-900" data-testid="short-term-1">Optimizar Recruitment Stack</div>
                            <div className="text-sm text-blue-700">Implementar IA para screening y matching automatizado</div>
                          </div>
                        </div>

                        <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                          <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5">2</div>
                          <div>
                            <div className="font-medium text-green-900" data-testid="short-term-2">Ampliar Employee Voice</div>
                            <div className="text-sm text-green-700">Implementar pulse surveys semanales y feedback 360º</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold text-foreground" data-testid="long-term-title">Largo Plazo (12-18 meses)</h4>
                      <div className="space-y-3">
                        <div className="flex items-start space-x-3 p-3 bg-purple-50 rounded-lg">
                          <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5">1</div>
                          <div>
                            <div className="font-medium text-purple-900" data-testid="long-term-1">Centro de Excelencia en IA</div>
                            <div className="text-sm text-purple-700">Establecer CoE para innovación en HR Tech</div>
                          </div>
                        </div>

                        <div className="flex items-start space-x-3 p-3 bg-orange-50 rounded-lg">
                          <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-0.5">2</div>
                          <div>
                            <div className="font-medium text-orange-900" data-testid="long-term-2">Ecosystem de Desarrollo</div>
                            <div className="text-sm text-orange-700">Plataforma integrada para upskilling y reskilling</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat">
              {module && (
                <AiChat 
                  moduleId={module.id} 
                  moduleName={module.name}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
