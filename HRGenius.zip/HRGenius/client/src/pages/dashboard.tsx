import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "@/components/layout/header";
import StatsCard from "@/components/ui/stats-card";
import ModuleCard from "@/components/ui/module-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, UserPlus, Zap, Brain, FileText, Target, Shield, Lightbulb, Heart, DollarSign, Crown } from "lucide-react";

const moduleIcons = {
  "WritingStyle": FileText,
  "SkillPathfinder": Target,
  "PeopleAnalytics Pro": Brain,
  "OrgDesign": Users,
  "HR Compliance": Shield,
  "DigitalTrans": Lightbulb,
  "Culture Engage": Heart,
  "Comp Rewards": DollarSign,
  "CHRO Advisor": Crown,
};

const moduleColors = {
  "WritingStyle": "#3b82f6",
  "SkillPathfinder": "#10b981",
  "PeopleAnalytics Pro": "#8b5cf6",
  "OrgDesign": "#f59e0b",
  "HR Compliance": "#ef4444",
  "DigitalTrans": "#6366f1",
  "Culture Engage": "#ec4899",
  "Comp Rewards": "#eab308",
  "CHRO Advisor": "#14b8a6",
};

export default function Dashboard() {
  const [, setLocation] = useLocation();

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: modules } = useQuery({
    queryKey: ["/api/modules"],
  });

  const handleModuleClick = (moduleName: string) => {
    const routeMap: Record<string, string> = {
      "WritingStyle": "/modules/writingstyle",
      "SkillPathfinder": "/modules/skillpathfinder",
      "PeopleAnalytics Pro": "/modules/peopleanalytics",
      "OrgDesign": "/modules/orgdesign",
      "HR Compliance": "/modules/compliance",
      "DigitalTrans": "/modules/digitaltrans",
      "Culture Engage": "/modules/culture",
      "Comp Rewards": "/modules/rewards",
      "CHRO Advisor": "/modules/chro",
    };
    
    const route = routeMap[moduleName];
    if (route) {
      setLocation(route);
    }
  };

  return (
    <>
      <Header 
        title="Dashboard Principal" 
        description="Gestión inteligente de recursos humanos con IA"
      />
      
      <main className="flex-1 overflow-y-auto p-6 bg-background">
        {/* KPIs principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Empleados Activos"
            value={(stats as any)?.activeEmployees || 0}
            change="+2.5% vs mes anterior"
            icon={Users}
          />
          
          <StatsCard
            title="Tasa de Retención"
            value={`${(stats as any)?.retentionRate || 0}%`}
            change="+1.2% vs mes anterior"
            icon={TrendingUp}
            iconColor="text-accent"
          />
          
          <StatsCard
            title="Nuevas Contrataciones"
            value={(stats as any)?.newHires || 0}
            change="Este mes"
            icon={UserPlus}
            iconColor="text-blue-600"
          />
          
          <StatsCard
            title="Consultas AI"
            value={(stats as any)?.aiQueries || 0}
            change="Últimas 24h"
            icon={Zap}
            iconColor="text-purple-600"
          />
        </div>

        {/* Módulos AI principales */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground" data-testid="modules-section-title">
              Módulos de Inteligencia Artificial
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(modules as any)?.map((module: any) => {
              const IconComponent = moduleIcons[module.name as keyof typeof moduleIcons] || Brain;
              const iconColor = moduleColors[module.name as keyof typeof moduleColors] || "#3b82f6";
              
              return (
                <ModuleCard
                  key={module.id}
                  title={module.name}
                  description={module.description}
                  icon={IconComponent}
                  iconColor={iconColor}
                  usageCount={module.usageCount}
                  performance={module.usageCount > 50 ? "Alto uso" : "Disponible"}
                  isActive={module.isActive}
                  onClick={() => handleModuleClick(module.name)}
                />
              );
            })}
          </div>
        </div>

        {/* Actividad reciente y insights */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Actividad reciente */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle data-testid="recent-activity-title">Actividad Reciente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <FileText className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground" data-testid="activity-writingstyle">
                      Análisis WritingStyle completado
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Sistema configurado y listo para análisis
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <Target className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground" data-testid="activity-skillpathfinder">
                      SkillPathfinder: Módulo activado
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Listo para mapeo de competencias
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <Brain className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground" data-testid="activity-peopleanalytics">
                      PeopleAnalytics: Sistema operativo
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Análisis de datos disponible
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Insights y recomendaciones */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle data-testid="ai-insights-title">Insights de IA</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                      <Brain className="w-3 h-3 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-blue-900" data-testid="insight-modules-ready">
                        Módulos AI configurados
                      </h4>
                      <p className="text-xs text-blue-700 mt-1">
                        Todos los módulos están listos para uso. Comienza analizando documentos o datos de empleados.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <Users className="w-3 h-3 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-green-900" data-testid="insight-integration-ready">
                        Sistema integrado
                      </h4>
                      <p className="text-xs text-green-700 mt-1">
                        La integración con ChatGPT está activa. Puedes comenzar a usar cualquier módulo especializado.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                      <Lightbulb className="w-3 h-3 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-yellow-900" data-testid="insight-get-started">
                        Comienza ahora
                      </h4>
                      <p className="text-xs text-yellow-700 mt-1">
                        Haz clic en cualquier módulo para comenzar a utilizar las capacidades de IA especializadas.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
