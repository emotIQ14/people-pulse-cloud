# Overview

RRHHBot GPT is a comprehensive HR intelligence platform that leverages AI to provide specialized modules for various human resources functions. The application features a modern web interface built with React and TypeScript, offering nine specialized AI-powered modules including WritingStyle analysis, SkillPathfinder, PeopleAnalytics Pro, OrgDesign, HR Compliance, DigitalTrans, Culture Engage, Comp Rewards, and CHRO Advisor. Each module provides interactive chat capabilities powered by OpenAI's GPT models, allowing HR professionals to get intelligent insights and recommendations for their specific needs.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built as a Single Page Application (SPA) using React 18 with TypeScript. The application uses Wouter for client-side routing instead of React Router, providing a lightweight navigation solution. State management is handled through React Query (@tanstack/react-query) for server state and React's built-in useState/useContext for local state. The UI framework leverages shadcn/ui components built on top of Radix UI primitives, providing a consistent and accessible design system with Tailwind CSS for styling.

## Backend Architecture
The server follows a RESTful API design pattern using Express.js with TypeScript in ES module format. The architecture separates concerns through distinct layers: routes handling HTTP endpoints, storage abstraction for data persistence, and services for external integrations. The server implements middleware for request logging, JSON parsing, and error handling. Currently uses an in-memory storage implementation (MemStorage) but provides an interface (IStorage) that can be extended for database integration.

## Data Storage Solutions
The application uses Drizzle ORM as the database abstraction layer with PostgreSQL as the target database (configured via DATABASE_URL environment variable). The schema defines four main entities: users, hrModules, conversations, and analytics, with proper foreign key relationships. While Drizzle is configured, the current implementation uses an in-memory storage system for development purposes, with the database integration ready for production deployment.

## Authentication and Authorization
The application currently operates without authentication, using a demo user approach for development. The schema includes user management tables and role-based access control foundations, indicating that authentication can be implemented when needed. Session management infrastructure is prepared with connect-pg-simple for PostgreSQL session storage.

## AI Integration Architecture
The core AI functionality is powered by OpenAI's GPT models through a service layer that abstracts chat completions and analysis requests. Each HR module has its own specialized system prompt and conversation context. The chat system supports conversation history, message threading, and module-specific AI personalities. Error handling and API key management are centralized in the OpenAI service layer.

# External Dependencies

## OpenAI Integration
Primary AI service provider using GPT models for conversational AI and analysis capabilities. Requires OPENAI_API_KEY environment variable for authentication. Each HR module can have specialized GPT configurations and system prompts.

## Database Services
PostgreSQL database configured through DATABASE_URL environment variable. Uses Neon Database serverless connector (@neondatabase/serverless) for cloud database connectivity. Drizzle ORM handles schema management and migrations.

## UI Component Libraries
Extensive use of Radix UI primitives for accessible, unstyled components. shadcn/ui provides pre-styled components built on Radix. Tailwind CSS handles utility-first styling with custom design tokens. Lucide React provides the icon system throughout the application.

## Development Tools
Vite serves as the build tool and development server with React plugin support. TypeScript provides type safety across the entire codebase. Replit-specific plugins handle development environment integration including error overlays and debugging tools.

## Utility Libraries
React Hook Form with Zod resolvers for form validation. TanStack Query manages server state, caching, and API interactions. Date-fns handles date manipulation. Embla Carousel provides carousel functionality. Various utility libraries support UI interactions and data processing.